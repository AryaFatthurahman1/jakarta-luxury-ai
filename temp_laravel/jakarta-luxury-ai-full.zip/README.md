# Jakarta Luxury AI

Platform Concierge bertenaga AI untuk gaya hidup mewah di Jakarta.

## Fitur Utama
- **Destinasi Wisata**: Jelajahi lokasi eksklusif seperti Pulau Macan dan Kota Tua VIP.
- **Jet Pribadi**: Reservasi penerbangan privat dengan armada Gulfstream dan Bombardier.
- **Hotel Bintang 5**: Akomodasi terbaik di Ritz-Carlton, Mulia, dan Raffles.
- **AI Concierge**: Asisten cerdas untuk merencanakan perjalanan Anda.

## Instalasi & Penggunaan

1.  **Persiapan Database**:
    - Pastikan database MySQL `jakarta_luxury_ai` sudah dibuat.
    - Jalankan migrasi dan seeder:
      ```bash
      php artisan migrate:fresh --seed
      ```

2.  **Menjalankan Aplikasi**:
    - Jalankan server development:
      ```bash
      php artisan serve
      ```
    - Jalankan kompilasi aset (Tailwind CSS):
      ```bash
      npm run dev
      ```

3.  **Akses**:
    - Buka browser di `http://localhost:8000`

## Struktur File (Bahasa Indonesia)
- `app/Http/Controllers/OtentikasiController.php`: Menangani Login & Daftar.
- `app/Models/Destinasi.php`: Model untuk data tempat wisata.
- `app/Models/Reservasi.php`: Model untuk data reservasi.
- `resources/views/beranda.blade.php`: Halaman utama "Jakarta Reimagined".
- `resources/views/wisata.blade.php`: Halaman layanan wisata & jet pribadi.

## Kontributor
- **Arya Fatthurahman**
